
export const Header = () => {
  return (
    <>
    <section id="hero" className="hero d-flex align-items-center">
        <div className="container">
          <div className="row">
            <div className="col-lg-6 d-flex flex-column justify-content-center">
              <h1 data-aos="fade-up">
                Innovative Music Event Ideas to Elevate the Experience
              </h1>
              <h2 data-aos="fade-up" data-aos-delay="400">
                ActSent | Part of GigStar
              </h2>
              <br />
              <h4 data-aos="fade-up" data-aos-delay="600">
                Find the perfect venue for your events.
              </h4>
            </div>
            <div
              className="col-lg-6 hero-img"
              data-aos="zoom-out"
              data-aos-delay="200"
            >
              <img
                src="assets/img/Music-Venue.svg"
                className="img-fluid"
                alt=""
              />
            </div>
          </div>
        </div>
      </section>
    </>
  )
}

export default Header