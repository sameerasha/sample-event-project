import Form from 'react-bootstrap/Form';

 const SearchEvents = () => {


   let handleSubmit =(event : any): void => {
    event.preventDefault();
   }

  return (
    <>
    <section id="event" className="footer">
        <div className="footer-newsletter">
          <div className="container">
            <div className="row justify-content-center">
              <div className="col-lg-12 text-center">
                <h2>Events</h2>
                <h4>Select a location for your event below</h4>
              </div>
              <div className="col-lg-6">
                <form onSubmit={(e) => handleSubmit(e)}>
                   <Form.Select size="lg" style={{width:'80%'}}>
                    <option>Large select</option>
                      </Form.Select>
                  <input type="submit" value="Search" />
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}

export default SearchEvents