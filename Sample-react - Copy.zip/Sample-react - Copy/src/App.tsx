import "./App.css";
import EventsCard from "./EventsCard";
import Footer from "./Footer";
import Forms from "./Forms";
import Header from "./Header";
import SearchEvents from "./SearchEvents";

function App() {
  return (
    <>
      <Header />
      <SearchEvents />
      <EventsCard />
      <Forms />
      <Footer />
    </>
  );
}

export default App;
