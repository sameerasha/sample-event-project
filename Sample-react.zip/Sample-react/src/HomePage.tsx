import EventsCard from "./EventsCard";
import Forms from "./Forms";
import SearchEvents from "./SearchEvents";

const HomePage = () => {
  return (
    <>
      <SearchEvents />
      <EventsCard />
      <Forms />
    </>
  );
};

export default HomePage;
