import { Route, Routes } from "react-router-dom";
import EventsCard from "./EventsCard";
import Forms from "./Forms";
import SearchEvents from "./SearchEvents";
import HomePage from "./HomePage";

export default function Routers() {
  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/searchevent" element={<SearchEvents />} />
      <Route path="/card" element={<EventsCard />} />
      <Route path="/form" element={<Forms />} />
    </Routes>
  );
}
